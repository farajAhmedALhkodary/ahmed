# PR3LabAssignments
This is the required Java project to fulfill the requirements of the first assignment requested..

Note: the username and password for the login inside the app are the following:

username: user
Password: userpass
